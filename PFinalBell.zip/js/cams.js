const getCams = function () {
  let HTML = `
        <div class="container">
            <div class="row">
                <div class="col">
                    <h3>Camaras de vigilancia</h3>
                    <img src="./images/camara.png" alt="camara">
                </div>
                <div class="col">
                    <br>
                    <b>Cam-1<button id="Rec-cam-1" class="RecButton Rec"></button></b> <span id="Status-cam-1"
                        class="badge badge-success">On</span>
                    <img src="./images/paisaje.jpg" alt="paisaje">
                    <div class="switches">
                        <input type="checkbox" name="cam-1" id="cam-1">
                    </div>
                </div>
                <div class="col">
                    <br>
                    <b>Cam-2<button id="Rec-cam-2" class="RecButton Rec"></button></b> <span id="Status-cam-2"
                        class="badge badge-success">On</span>
                    <img src="./images/paisaje.jpg" alt="paisaje">
                    <div class="switches">
                        <input type="checkbox" name="cam-2" id="cam-2">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                </div>
                <div class="col">
                    <br>
                    <b>Cam-3<button id="Rec-cam-3" class="RecButton Rec"></button></b> <span id="Status-cam-3"
                        class="badge badge-success">On</span>
                    <img src="./images/paisaje.jpg" alt="paisaje">
                    <div class="switches">
                        <input type="checkbox" name="cam-3" id="cam-3">
                    </div>
                </div>
                <div class="col">
                    <br>
                    <b>Cam-4<button id="Rec-cam-4" class="RecButton Rec"></button></b> <span id="Status-cam-4"
                        class="badge badge-success">On</span>
                    <img src="./images/paisaje.jpg" alt="paisaje">
                    <div class="switches">
                        <input type="checkbox" name="cam-4" id="cam-4">
                    </div>

                </div>
            </div>
        </div>
    `;
  //HTML = `<h1>Pruebas</h1>`;
  return HTML;
};

const toggleOnCam = (id) => {
  let $recButton = document.getElementById(`Rec-${id}`),
    $spanStatus = document.getElementById(`Status-${id}`),
    $onOffinput = document.getElementById(id);

  $recButton.classList.value = "RecButton Rec";
  $spanStatus.classList.value = "badge badge-success";
  $spanStatus.textContent = "On";
  $onOffinput.checked = true;
};
const toggleOffCam = (id) => {
  let $recButton = document.getElementById(`Rec-${id}`),
    $spanStatus = document.getElementById(`Status-${id}`),
    $onOffinput = document.getElementById(id);

  $recButton.classList.value = "RecButton notRec";
  $spanStatus.classList.value = "badge badge-secondary";
  $spanStatus.textContent = "Off";
  $onOffinput.checked = false;
};

const getStatusCams = function () {
  const d = document,
    ls = localStorage;
  //Variables que se cargan al iniciar la pagina
  let camsList = ["cam-1", "cam-2", "cam-3", "cam-4"];
  camsList.forEach((el) => {
    if (ls.getItem(`${el}`) == null) ls.setItem(`${el}`, "off");
    if (ls.getItem(`${el}`) == "On") toggleOnCam(el);
    if (ls.getItem(`${el}`) == "Off") toggleOffCam(el);
  });
};

export const systemCams = {
  getCams,
  getStatusCams,
  toggleOnCam,
  toggleOffCam,
};
