const setClock = function () {
  let $reloj = document.getElementById("reloj");
  let fecha = new Date().toLocaleString(),
    ls = localStorage;
  $reloj.innerHTML = `<p><b>${fecha}</b></p>`;
  ls.setItem("lastAccess", fecha);
  console.log("Soy el reloj");
  console.log($reloj);
};

const getLastAccess = function () {
  let $acceso = document.getElementById("lastAccess"),
    $programados = document.getElementById("programados"),
    ls = localStorage,
    lastAccess = "";

  lastAccess = ls.getItem("lastAccess") || new Date().toLocaleString();
  $acceso.innerHTML = `<p><i>Ultimo acceso: ${lastAccess}</i></p>`;

  if (ls.getItem("FechaApagado") !== null) {
    //console.log(ls.getItem("dateValid"));
    if (new Date(ls.getItem("dateValid")) < new Date()) {
      console.log("entre a la validación");
      ls.clear();
      $programados.innerHTML = "";
    } else {
      $programados.innerHTML = `
      <br>
      <h4><b>Apagado programado: </b></h4>
      <br>
      <p>Fecha: ${ls.getItem("FechaApagado")} hora: ${ls.getItem("HoraApagado")}
      <button id="delDate" type="button" class="btn btn-danger btn-sm">Eliminar</button>
      </p>
      `;
    }
  }
};

const setOffServices = function () {
  let date = document.getElementById("dateOff"),
    timeOff = document.getElementById("timeOff"),
    $programados = document.getElementById("programados"),
    ls = localStorage;
  let fechaCreada = new Date(`${date.value} ${timeOff.value}`);
  console.log(fechaCreada);
  ls.setItem("dateValid", fechaCreada);
  ls.setItem("FechaApagado", date.value);
  ls.setItem("HoraApagado", timeOff.value);
  $programados.innerHTML = `
    <br>
    <h4><b>Apagado programado: </b></h4>
    <br>
    <p>Fecha: ${date.value} hora: ${timeOff.value}
    <button id="delDate" type="button" class="btn btn-danger btn-sm">Eliminar</button>
    </p>
    `;
  location.reload();
};
const delOffServices = function () {
  let $programados = document.getElementById("programados"),
    ls = localStorage;
  ls.removeItem("FechaApagado");
  ls.removeItem("HoraApagado");
  $programados.innerHTML = " ";
};

const shutDownServices = function () {
  let ls = localStorage;
  let message = "Se apagaran todos los servicios";
  if (confirm(message)) {
    ls.clear();
    location.reload();
  }
};

export const systemMain = {
  setClock,
  getLastAccess,
  setOffServices,
  delOffServices,
  shutDownServices,
};
