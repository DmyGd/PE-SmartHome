const getDoors = function () {
  let HTML = `
   <div class="container">
            <div class="row">
                <div class="col">
                    <h3><b>Control de puertas y garage</b></h3>
                </div>
                <div class="col">
                    <br>
                    <b>Puerta pricipal </b><span id="Status-puerta-1" class="badge badge-secondary">Closed</span>
                    <div class="switches">
                        <input type="checkbox" name="puerta-1" id="puerta-1">
                    </div>
                    <img id="img-puerta-1" src="./images/PuertaCloseB.jpg" alt="Cerrada">
                </div>
                <div class="col">
                    <br>
                    <b>Garage </b><span id="Status-puerta-2" class="badge badge-secondary">Closed</span>
                    <div class="switches">
                        <input type="checkbox" name="puerta-2" id="puerta-2">
                    </div>
                    <img id="img-puerta-2" src="./images/garageCerr.png" alt="cerrado">
                </div>
            </div>
        </div>
  `;
  return HTML;
};

const toggleOnDoor = (id) => {
  let $spanStatus = document.getElementById(`Status-${id}`),
    $onOffinput = document.getElementById(id);

  if (`img-${id}` == "img-puerta-1") {
    let $img = document.getElementById(`img-${id}`);
    $img.src = "./images/PuertaOpenW.png";
  }
  if (`img-${id}` == "img-puerta-2") {
    let $img = document.getElementById(`img-${id}`);
    $img.src = "./images/garageAB.png";
  }

  $spanStatus.classList.value = "badge badge-danger";
  $spanStatus.textContent = "Opened!";
  $onOffinput.checked = true;
};

const toggleOffDoor = (id) => {
  let $spanStatus = document.getElementById(`Status-${id}`),
    $onOffinput = document.getElementById(id);

  if (`img-${id}` == "img-puerta-1") {
    let $img = document.getElementById(`img-${id}`);
    $img.src = "./images/PuertaCloseB.jpg";
  }
  if (`img-${id}` == "img-puerta-2") {
    let $img = document.getElementById(`img-${id}`);
    $img.src = "./images/garageCerr.png";
  }

  $spanStatus.classList.value = "badge badge-secondary";
  $spanStatus.textContent = "Closed";
  $onOffinput.checked = false;
};

const getStatusDoors = function () {
  const d = document,
    ls = localStorage;
  //Variables que se cargan al iniciar la pagina
  let doorsList = ["puerta-1", "puerta-2"];
  doorsList.forEach((el) => {
    if (ls.getItem(`${el}`) == null) ls.setItem(`${el}`, "Closed");
    if (ls.getItem(`${el}`) == "Opened") toggleOnDoor(el);
    if (ls.getItem(`${el}`) == "Closed") toggleOffDoor(el);
  });
};

export const systemDoors = {
  getDoors,
  getStatusDoors,
  toggleOnDoor,
  toggleOffDoor,
};
