const getLights = function () {
  let HTML = `
   <div class="container">
            <div class="row">
                <div class="col">
                    <h3>Control de luces</h3>
                    <img src="./images/focopag.png" alt="Control de luces">
                </div>
                <div class="col">
                    <br>
                    <b>Luz cochera </b><span id="Status-luz-1" class="badge badge-secondary">Off</span>
                    <div class="switches">
                        <input type="checkbox" name="luz-1" id="luz-1">
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="formControlRange">Intensidad de luz</label>
                        <input id="slider-luz-1" type="range" class="form-control-range" min="1" max="15" value="10"
                            step="1">
                    </div>
                </div>
                <div class="col">
                    <br>
                    <b> Luz Patio </b><span id="Status-luz-2" class="badge badge-secondary">Off</span>
                    <div class="switches">
                        <input type="checkbox" name="luz-2" id="luz-2">
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="formControlRange">Intensidad de luz</label>
                        <input id="slider-luz-2" type="range" class="form-control-range" min="1" max="15" value="10"
                            step="1">
                    </div>

                </div>
                <div class="col">
                    <br>
                    <b> Luz Sala </b><span id="Status-luz-3" class="badge badge-secondary">Off</span>
                    <div class="switches">
                        <input type="checkbox" name="luz-3" id="luz-3">
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="formControlRange">Intensidad de luz</label>
                        <input id="slider-luz-3" type="range" class="form-control-range" min="1" max="15" value="10"
                            step="1">
                    </div>

                </div>
            </div>
            <!--  -->
            <div class="row">
                <div class="col">

                </div>
                <div class="col">
                    <br>
                    <b>Luz cocina </b><span id="Status-luz-4" class="badge badge-secondary">Off</span>
                    <div class="switches">
                        <input type="checkbox" name="luz-4" id="luz-4">
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="formControlRange">Intensidad de luz</label>
                        <input id="slider-luz-4" type="range" class="form-control-range" min="1" max="15" value="10"
                            step="1">
                    </div>
                </div>
                <div class="col">
                    <br>
                    <b> Luz cuarto-1 </b><span id="Status-luz-5" class="badge badge-secondary">Off</span>
                    <div class="switches">
                        <input type="checkbox" name="luz-5" id="luz-5">
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="formControlRange">Intensidad de luz</label>
                        <input id="slider-luz-5" type="range" class="form-control-range" min="1" max="15" value="10"
                            step="1">
                    </div>

                </div>
                <div class="col">
                    <br>
                    <b> Luz cuarto-2 </b><span id="Status-luz-6" class="badge badge-secondary">Off</span>
                    <div class="switches">
                        <input type="checkbox" name="luz-6" id="luz-6">
                    </div>
                    <br>
                    <div class="form-group">
                        <label for="formControlRange">Intensidad de luz</label>
                        <input id="slider-luz-6" type="range" class="form-control-range" min="1" max="15" value="10"
                            step="1">
                    </div>
                </div>
            </div>
        </div>
    `;
  return HTML;
};
const toggleOnLight = (id) => {
  const ls = localStorage;
  let $spanStatus = document.getElementById(`Status-${id}`),
    $slider = document.getElementById(`slider-${id}`),
    $onOffinput = document.getElementById(id);

  $spanStatus.classList.value = "badge badge-success";
  $spanStatus.textContent = "On";
  $onOffinput.checked = true;
  $slider.value = ls.getItem(`slider-${id}`);
  console.log($slider.value);
};
const toggleOffLight = (id) => {
  const ls = localStorage;
  let $spanStatus = document.getElementById(`Status-${id}`),
    $slider = document.getElementById(`slider-${id}`),
    $onOffinput = document.getElementById(id);

  $spanStatus.classList.value = "badge badge-secondary";
  $spanStatus.textContent = "Off";
  $onOffinput.checked = false;
  $slider.value = ls.getItem(`slider-${id}`);
  console.log($slider.value);
};
const getStatusLights = function () {
  const d = document,
    ls = localStorage;
  //Variables que se cargan al iniciar la pagina
  let lightsList = ["luz-1", "luz-2", "luz-3", "luz-4", "luz-5", "luz-6"];
  lightsList.forEach((el) => {
    if (ls.getItem(`${el}`) == null) ls.setItem(`${el}`, "off");
    if (ls.getItem(`slider-${el}`) == null) ls.setItem(`slider-${el}`, 7);
    if (ls.getItem(`${el}`) == "On") toggleOnLight(el);
    if (ls.getItem(`${el}`) == "Off") toggleOffLight(el);
  });
};

export const systemLights = {
  getLights,
  getStatusLights,
  toggleOnLight,
  toggleOffLight,
};
