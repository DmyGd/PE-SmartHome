import { systemCams } from "./cams.js";
import { dataFetch } from "./em_fetch.js";
import { systemLights } from "./sliderRange.js";
import { systemDoors } from "./door.js";
import { systemMain } from "./home.js";
//componentes sin logica

document.addEventListener("DOMContentLoaded", (e) => {
  systemMain.getLastAccess();
  systemMain.setClock();
});

const main = () => {
  const d = document,
    ls = localStorage;
  const $section = document.getElementById("Seccion");

  d.addEventListener("click", (e) => {
    if (e.target.matches("#setOffServices")) {
      console.log("Programando apagado");
      systemMain.setOffServices();
    }
    if (e.target.matches("#delDate")) {
      console.log("Eliminando apagado");
      systemMain.delOffServices();
    }
    if (e.target.matches("#shutDown")) {
      console.log("Eliminando apagado");
      systemMain.shutDownServices();
    }

    //console.log(e);
    if (e.target.matches("#cams")) {
      //console.log("Soy la camara");
      //d.querySelector(".loader").style.display = "block";
      $section.innerHTML = "";
      $section.innerHTML = systemCams.getCams();
      systemCams.getStatusCams();
      //d.querySelector(".loader").style.display = "none";
    }
    if (e.target.matches("#light")) {
      //console.log("Soy la luz");
      $section.innerHTML = "";
      $section.innerHTML = systemLights.getLights();
      systemLights.getStatusLights();
    }
    if (e.target.matches("#bell")) {
      //console.log("Soy el timbre");
      $section.innerHTML = "";
      $section.innerHTML = `
      <h1> Interfaz de Timbres </h1>
      `;
    }
    if (e.target.matches("#door")) {
      //console.log("Soy la puerta");
      $section.innerHTML = "";
      $section.innerHTML = systemDoors.getDoors();
      systemDoors.getStatusDoors();
    }
    if (e.target.matches("#cam-1")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        console.log("Se prendio la camara-1");
        ls.setItem("cam-1", "On");
        systemCams.toggleOnCam("cam-1");
        dataFetch.json_data.camaras[0] = [1, "On"];
      } else {
        console.log("Se apago la camara-4");
        ls.setItem("cam-1", "Off");
        systemCams.toggleOffCam("cam-1");
        dataFetch.json_data.camaras[0] = [1, "Off"];
      }
      console.log(dataFetch.json_data.camaras);
      dataFetch.sentData();
    }
    if (e.target.matches("#cam-2")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        console.log("Se prendio la camara-2");
        ls.setItem("cam-2", "On");
        systemCams.toggleOnCam("cam-2");
        dataFetch.json_data.camaras[1] = [2, "On"];
      } else {
        console.log("Se apago la camara-2");
        ls.setItem("cam-2", "Off");
        systemCams.toggleOffCam("cam-2");
        dataFetch.json_data.camaras[1] = [2, "Off"];
      }
      console.log(dataFetch.json_data.camaras);
      dataFetch.sentData();
    }
    if (e.target.matches("#cam-3")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        console.log("Se prendio la camara-3");
        ls.setItem("cam-3", "On");
        systemCams.toggleOnCam("cam-3");
        dataFetch.json_data.camaras[2] = [3, "On"];
      } else {
        console.log("Se apago la camara-3");
        ls.setItem("cam-3", "Off");
        systemCams.toggleOffCam("cam-3");
        dataFetch.json_data.camaras[2] = [3, "Off"];
      }
      console.log(dataFetch.json_data.camaras);
      dataFetch.sentData();
      dataFetch.sentData();
    }
    if (e.target.matches("#cam-4")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("cam-4", "On");
        console.log("Se prendio la camara-4");
        systemCams.toggleOnCam("cam-4");
        dataFetch.json_data.camaras[0] = [4, "On"];
      } else {
        console.log("Se apago la camara-4");
        ls.setItem("cam-4", "Off");
        systemCams.toggleOffCam("cam-4");
        dataFetch.json_data.camaras[3] = [4, "Off"];
      }
      console.log(dataFetch.json_data.camaras);
      dataFetch.sentData();
    }
    /*======= Luces =======*/
    if (e.target.matches("#luz-1")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("luz-1", "On");
        console.log("Se prendio la luz-1");
        systemLights.toggleOnLight("luz-1");
      } else {
        ls.setItem("luz-1", "Off");
        console.log("Se apago la luz-1");
        systemLights.toggleOffLight("luz-1");
      }
    }
    if (e.target.matches("#luz-2")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("luz-2", "On");
        console.log("Se prendio la luz-2");
        systemLights.toggleOnLight("luz-2");
      } else {
        ls.setItem("luz-2", "Off");
        console.log("Se apago la luz-2");
        systemLights.toggleOffLight("luz-2");
      }
    }
    if (e.target.matches("#luz-3")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("luz-3", "On");
        console.log("Se prendio la luz-3");
        systemLights.toggleOnLight("luz-3");
      } else {
        ls.setItem("luz-3", "Off");
        console.log("Se apago la luz-3");
        systemLights.toggleOffLight("luz-3");
      }
    }
    if (e.target.matches("#luz-4")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("luz-4", "On");
        console.log("Se prendio la luz-4");
        systemLights.toggleOnLight("luz-4");
      } else {
        ls.setItem("luz-4", "Off");
        console.log("Se apago la luz-4");
        systemLights.toggleOffLight("luz-4");
      }
    }
    if (e.target.matches("#luz-5")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("luz-5", "On");
        console.log("Se prendio la luz-5");
        systemLights.toggleOnLight("luz-5");
      } else {
        ls.setItem("luz-5", "Off");
        console.log("Se apago la luz-5");
        systemLights.toggleOffLight("luz-5");
      }
    }
    if (e.target.matches("#luz-6")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("luz-6", "On");
        console.log("Se prendio la luz-6");
        systemLights.toggleOnLight("luz-6");
      } else {
        ls.setItem("luz-6", "Off");
        console.log("Se apago la luz-6");
        systemLights.toggleOffLight("luz-6");
      }
    }
    /*=== Puertas ===*/
    if (e.target.matches("#puerta-1")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("puerta-1", "Opened");
        console.log("Se abrio la puerta puerta-1");
        systemDoors.toggleOnDoor("puerta-1");
      } else {
        ls.setItem("puerta-1", "Closed");
        console.log("Se cerro la puerta-1");
        systemDoors.toggleOffDoor("puerta-1");
      }
    }
    if (e.target.matches("#puerta-2")) {
      console.log(e.target.checked);
      if (e.target.checked) {
        ls.setItem("puerta-2", "Opened");
        console.log("Se abrio la puerta puerta-2");
        systemDoors.toggleOnDoor("puerta-2");
      } else {
        ls.setItem("puerta-2", "Closed");
        console.log("Se cerro la puerta-2");
        systemDoors.toggleOffDoor("puerta-2");
      }
    }
  });
  /* Manejo de eventos del Slider */
  d.addEventListener("input", (e) => {
    let lights = ["luz-1", "luz-2", "luz-3", "luz-4", "luz-5", "luz-6"];
    if (e.target.matches("#slider-luz-1")) {
      console.log(e.target.value);
      ls.setItem("slider-luz-1", e.target.value);
    }
    if (e.target.matches("#slider-luz-2")) {
      console.log(e.target.value);
      ls.setItem("slider-luz-2", e.target.value);
    }
    if (e.target.matches("#slider-luz-3")) {
      console.log(e.target.value);
      ls.setItem("slider-luz-3", e.target.value);
    }
    if (e.target.matches("#slider-luz-4")) {
      console.log(e.target.value);
      ls.setItem("slider-luz-4", e.target.value);
    }
    if (e.target.matches("#slider-luz-5")) {
      console.log(e.target.value);
      ls.setItem("slider-luz-5", e.target.value);
    }
    if (e.target.matches("#slider-luz-6")) {
      console.log(e.target.value);
      ls.setItem("slider-luz-6", e.target.value);
    }
  });
};

main();
