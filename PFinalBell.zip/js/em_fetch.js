const json_data = {
  camaras: [
    [1, "Off"],
    [2, "Off"],
    [3, "Off"],
    [4, "Off"],
  ],
  luces: [],
  timbre: [],
  Puertas: [],
};

const ajax = (options) => {
  let { url, method, success, error, data } = options;
  const xhr = new XMLHttpRequest();

  xhr.addEventListener("readystatechange", (e) => {
    if (xhr.readyState !== 4) return;
    if (xhr.status >= 200 && xhr.status < 300) {
      let json = JSON.parse(xhr.responseText);
      success(json);
    } else {
      let message = xhr.statusText || "Ocurrio un error";
      error(`Error: ${xhr.status}: ${message}`);
    }
  });
  xhr.open(method || "GET", url); //si no se coloca el parametro, es get por default
  xhr.withCredentials = "*";
  xhr.setRequestHeader("Content-type", "application/json; charset=utf-8");
  xhr.send(JSON.stringify(data));
};

const sentData = async () => {
  const d = document;
  let $section = d.getElementById("Seccion");
  try {
    let options = {
        method: "POST",
        credentials: "omit",
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify(json_data),
      },
      res = await fetch("http://localhost:8080/", options),
      json = await res.json();
    if (!res.ok) throw { status: res.status, statusText: res.statusText };
  } catch (err) {
    let message = err.statusText || "Ocurrio un error";
    $section.insertAdjacentHTML(
      "afterend",
      `<p><b>${err.status}: ${message} </b></p>`
    );
  }
};

export const dataFetch = {
  json_data,
  sentData,
};
