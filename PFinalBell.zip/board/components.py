#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# ## #############################################################
# components.py
#
# Author: Mauricio Matamoros
# Date:
#
# ## #############################################################
# Future imports (Python 2.7 compatibility)
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import re
import sys


def main():
	pass


if __name__ == '__main__':
	main()
