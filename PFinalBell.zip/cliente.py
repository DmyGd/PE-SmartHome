#Autores
#Dominguez Duran Gerardo 
#Méndez Cabrera Ana Belem
#Rodríguez Sánchez José Andrés
import socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#quehost? borrar al resolver xd
server_address = ('192.168.0.122',12345)
sock.connect(server_address)

try:
    message = "1"
    message = bytes(message, 'utf-8')
    sock.sendall(message)
    print("Llegó el mensaje")
finally:
    print('Cerrar socket')
    sock.close()